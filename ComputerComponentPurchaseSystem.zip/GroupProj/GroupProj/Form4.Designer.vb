﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabCase = New System.Windows.Forms.TabPage()
        Me.txtPC = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnPC = New System.Windows.Forms.Button()
        Me.radPC4 = New System.Windows.Forms.RadioButton()
        Me.radPC2 = New System.Windows.Forms.RadioButton()
        Me.radPC3 = New System.Windows.Forms.RadioButton()
        Me.radPC1 = New System.Windows.Forms.RadioButton()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.tabMB = New System.Windows.Forms.TabPage()
        Me.txtMB = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnMB = New System.Windows.Forms.Button()
        Me.radMB4 = New System.Windows.Forms.RadioButton()
        Me.radMB3 = New System.Windows.Forms.RadioButton()
        Me.radMB2 = New System.Windows.Forms.RadioButton()
        Me.radMB1 = New System.Windows.Forms.RadioButton()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.tabCPU = New System.Windows.Forms.TabPage()
        Me.txtCP = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnCP = New System.Windows.Forms.Button()
        Me.radCP4 = New System.Windows.Forms.RadioButton()
        Me.radCP3 = New System.Windows.Forms.RadioButton()
        Me.radCP2 = New System.Windows.Forms.RadioButton()
        Me.radCP1 = New System.Windows.Forms.RadioButton()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.tabPSU = New System.Windows.Forms.TabPage()
        Me.txtPS = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnPS = New System.Windows.Forms.Button()
        Me.radPS4 = New System.Windows.Forms.RadioButton()
        Me.radPS3 = New System.Windows.Forms.RadioButton()
        Me.radPS2 = New System.Windows.Forms.RadioButton()
        Me.radPS1 = New System.Windows.Forms.RadioButton()
        Me.PictureBox21 = New System.Windows.Forms.PictureBox()
        Me.PictureBox22 = New System.Windows.Forms.PictureBox()
        Me.PictureBox23 = New System.Windows.Forms.PictureBox()
        Me.PictureBox24 = New System.Windows.Forms.PictureBox()
        Me.tabGPU = New System.Windows.Forms.TabPage()
        Me.txtGP = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnGP = New System.Windows.Forms.Button()
        Me.radGP4 = New System.Windows.Forms.RadioButton()
        Me.radGP3 = New System.Windows.Forms.RadioButton()
        Me.radGP2 = New System.Windows.Forms.RadioButton()
        Me.radGP1 = New System.Windows.Forms.RadioButton()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.tabRAM = New System.Windows.Forms.TabPage()
        Me.txtR = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnR = New System.Windows.Forms.Button()
        Me.radR4 = New System.Windows.Forms.RadioButton()
        Me.radR3 = New System.Windows.Forms.RadioButton()
        Me.radR2 = New System.Windows.Forms.RadioButton()
        Me.radR1 = New System.Windows.Forms.RadioButton()
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.PictureBox19 = New System.Windows.Forms.PictureBox()
        Me.PictureBox20 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.imgCart = New System.Windows.Forms.PictureBox()
        Me.lblCart = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.tabCase.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabMB.SuspendLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabCPU.SuspendLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabPSU.SuspendLayout()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabGPU.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabRAM.SuspendLayout()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.imgCart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabCase)
        Me.TabControl1.Controls.Add(Me.tabMB)
        Me.TabControl1.Controls.Add(Me.tabCPU)
        Me.TabControl1.Controls.Add(Me.tabPSU)
        Me.TabControl1.Controls.Add(Me.tabGPU)
        Me.TabControl1.Controls.Add(Me.tabRAM)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(149, 106)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(895, 405)
        Me.TabControl1.TabIndex = 6
        '
        'tabCase
        '
        Me.tabCase.BackColor = System.Drawing.Color.Black
        Me.tabCase.Controls.Add(Me.txtPC)
        Me.tabCase.Controls.Add(Me.Label1)
        Me.tabCase.Controls.Add(Me.btnPC)
        Me.tabCase.Controls.Add(Me.radPC4)
        Me.tabCase.Controls.Add(Me.radPC2)
        Me.tabCase.Controls.Add(Me.radPC3)
        Me.tabCase.Controls.Add(Me.radPC1)
        Me.tabCase.Controls.Add(Me.PictureBox2)
        Me.tabCase.Controls.Add(Me.PictureBox4)
        Me.tabCase.Controls.Add(Me.PictureBox1)
        Me.tabCase.Controls.Add(Me.PictureBox3)
        Me.tabCase.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabCase.Location = New System.Drawing.Point(4, 36)
        Me.tabCase.Name = "tabCase"
        Me.tabCase.Padding = New System.Windows.Forms.Padding(3)
        Me.tabCase.Size = New System.Drawing.Size(887, 365)
        Me.tabCase.TabIndex = 0
        Me.tabCase.Text = "Casing"
        '
        'txtPC
        '
        Me.txtPC.Location = New System.Drawing.Point(569, 331)
        Me.txtPC.Name = "txtPC"
        Me.txtPC.Size = New System.Drawing.Size(100, 24)
        Me.txtPC.TabIndex = 22
        Me.txtPC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(482, 334)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 19)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Quantity(s)"
        '
        'btnPC
        '
        Me.btnPC.Location = New System.Drawing.Point(675, 327)
        Me.btnPC.Name = "btnPC"
        Me.btnPC.Size = New System.Drawing.Size(206, 32)
        Me.btnPC.TabIndex = 20
        Me.btnPC.Text = "Add To Cart"
        Me.btnPC.UseVisualStyleBackColor = True
        '
        'radPC4
        '
        Me.radPC4.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPC4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radPC4.Location = New System.Drawing.Point(675, 219)
        Me.radPC4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radPC4.Name = "radPC4"
        Me.radPC4.Size = New System.Drawing.Size(198, 66)
        Me.radPC4.TabIndex = 19
        Me.radPC4.TabStop = True
        Me.radPC4.Text = "HYTE Revolt 3 ITX" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 240.00"
        Me.radPC4.UseVisualStyleBackColor = True
        '
        'radPC2
        '
        Me.radPC2.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPC2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radPC2.Location = New System.Drawing.Point(235, 219)
        Me.radPC2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radPC2.Name = "radPC2"
        Me.radPC2.Size = New System.Drawing.Size(198, 66)
        Me.radPC2.TabIndex = 18
        Me.radPC2.TabStop = True
        Me.radPC2.Text = "Ronaldo Gaming Case" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 700.00"
        Me.radPC2.UseVisualStyleBackColor = True
        '
        'radPC3
        '
        Me.radPC3.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPC3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radPC3.Location = New System.Drawing.Point(455, 219)
        Me.radPC3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radPC3.Name = "radPC3"
        Me.radPC3.Size = New System.Drawing.Size(198, 66)
        Me.radPC3.TabIndex = 17
        Me.radPC3.TabStop = True
        Me.radPC3.Text = "MONTECH SKY ONE MINI" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 180.00"
        Me.radPC3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radPC3.UseVisualStyleBackColor = True
        '
        'radPC1
        '
        Me.radPC1.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPC1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radPC1.Location = New System.Drawing.Point(15, 216)
        Me.radPC1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radPC1.Name = "radPC1"
        Me.radPC1.Size = New System.Drawing.Size(186, 72)
        Me.radPC1.TabIndex = 16
        Me.radPC1.TabStop = True
        Me.radPC1.Text = "ASUS A21 mATX Casing – Black" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 220.00"
        Me.radPC1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radPC1.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = Global.GroupProj.My.Resources.Resources._case
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(15, 15)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox2.TabIndex = 13
        Me.PictureBox2.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = Global.GroupProj.My.Resources.Resources.case_salasatun
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.Location = New System.Drawing.Point(675, 15)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox4.TabIndex = 15
        Me.PictureBox4.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.GroupProj.My.Resources.Resources.case_dua
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(235, 15)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = Global.GroupProj.My.Resources.Resources.case_office
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Location = New System.Drawing.Point(455, 15)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox3.TabIndex = 14
        Me.PictureBox3.TabStop = False
        '
        'tabMB
        '
        Me.tabMB.BackColor = System.Drawing.Color.Black
        Me.tabMB.Controls.Add(Me.txtMB)
        Me.tabMB.Controls.Add(Me.Label2)
        Me.tabMB.Controls.Add(Me.btnMB)
        Me.tabMB.Controls.Add(Me.radMB4)
        Me.tabMB.Controls.Add(Me.radMB3)
        Me.tabMB.Controls.Add(Me.radMB2)
        Me.tabMB.Controls.Add(Me.radMB1)
        Me.tabMB.Controls.Add(Me.PictureBox13)
        Me.tabMB.Controls.Add(Me.PictureBox14)
        Me.tabMB.Controls.Add(Me.PictureBox15)
        Me.tabMB.Controls.Add(Me.PictureBox16)
        Me.tabMB.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabMB.Location = New System.Drawing.Point(4, 36)
        Me.tabMB.Name = "tabMB"
        Me.tabMB.Padding = New System.Windows.Forms.Padding(3)
        Me.tabMB.Size = New System.Drawing.Size(887, 365)
        Me.tabMB.TabIndex = 1
        Me.tabMB.Text = "MotherBoard"
        '
        'txtMB
        '
        Me.txtMB.Location = New System.Drawing.Point(569, 331)
        Me.txtMB.Name = "txtMB"
        Me.txtMB.Size = New System.Drawing.Size(100, 24)
        Me.txtMB.TabIndex = 47
        Me.txtMB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(482, 334)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 19)
        Me.Label2.TabIndex = 46
        Me.Label2.Text = "Quantity(s)"
        '
        'btnMB
        '
        Me.btnMB.Location = New System.Drawing.Point(675, 327)
        Me.btnMB.Name = "btnMB"
        Me.btnMB.Size = New System.Drawing.Size(206, 32)
        Me.btnMB.TabIndex = 45
        Me.btnMB.Text = "Add To Cart"
        Me.btnMB.UseVisualStyleBackColor = True
        '
        'radMB4
        '
        Me.radMB4.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radMB4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radMB4.Location = New System.Drawing.Point(675, 219)
        Me.radMB4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radMB4.Name = "radMB4"
        Me.radMB4.Size = New System.Drawing.Size(200, 65)
        Me.radMB4.TabIndex = 44
        Me.radMB4.TabStop = True
        Me.radMB4.Text = "MSi AMD B550M K AM4 " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 400.00"
        Me.radMB4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radMB4.UseVisualStyleBackColor = True
        '
        'radMB3
        '
        Me.radMB3.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radMB3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radMB3.Location = New System.Drawing.Point(455, 219)
        Me.radMB3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radMB3.Name = "radMB3"
        Me.radMB3.Size = New System.Drawing.Size(200, 65)
        Me.radMB3.TabIndex = 43
        Me.radMB3.TabStop = True
        Me.radMB3.Text = "GIGABYTE AMD B450M K AM4 " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 470.00"
        Me.radMB3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.radMB3.UseVisualStyleBackColor = True
        '
        'radMB2
        '
        Me.radMB2.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radMB2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radMB2.Location = New System.Drawing.Point(236, 219)
        Me.radMB2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radMB2.Name = "radMB2"
        Me.radMB2.Size = New System.Drawing.Size(199, 66)
        Me.radMB2.TabIndex = 42
        Me.radMB2.TabStop = True
        Me.radMB2.Text = "ASROCK B550M ITX/AC AM4" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 630.00"
        Me.radMB2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radMB2.UseVisualStyleBackColor = True
        '
        'radMB1
        '
        Me.radMB1.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radMB1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radMB1.Location = New System.Drawing.Point(15, 219)
        Me.radMB1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radMB1.Name = "radMB1"
        Me.radMB1.Size = New System.Drawing.Size(200, 66)
        Me.radMB1.TabIndex = 41
        Me.radMB1.TabStop = True
        Me.radMB1.Text = "ASROCK B450M Steel Legend AM4" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 400.00"
        Me.radMB1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radMB1.UseVisualStyleBackColor = True
        '
        'PictureBox13
        '
        Me.PictureBox13.BackColor = System.Drawing.Color.White
        Me.PictureBox13.BackgroundImage = Global.GroupProj.My.Resources.Resources.mother4
        Me.PictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox13.Location = New System.Drawing.Point(675, 15)
        Me.PictureBox13.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox13.TabIndex = 40
        Me.PictureBox13.TabStop = False
        '
        'PictureBox14
        '
        Me.PictureBox14.BackgroundImage = Global.GroupProj.My.Resources.Resources.mother3
        Me.PictureBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox14.Location = New System.Drawing.Point(455, 15)
        Me.PictureBox14.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox14.TabIndex = 39
        Me.PictureBox14.TabStop = False
        '
        'PictureBox15
        '
        Me.PictureBox15.BackgroundImage = Global.GroupProj.My.Resources.Resources.mother2
        Me.PictureBox15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox15.Location = New System.Drawing.Point(235, 15)
        Me.PictureBox15.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox15.TabIndex = 38
        Me.PictureBox15.TabStop = False
        '
        'PictureBox16
        '
        Me.PictureBox16.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox16.BackgroundImage = Global.GroupProj.My.Resources.Resources.mother1
        Me.PictureBox16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox16.Location = New System.Drawing.Point(15, 15)
        Me.PictureBox16.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox16.TabIndex = 37
        Me.PictureBox16.TabStop = False
        '
        'tabCPU
        '
        Me.tabCPU.BackColor = System.Drawing.Color.Black
        Me.tabCPU.Controls.Add(Me.txtCP)
        Me.tabCPU.Controls.Add(Me.Label3)
        Me.tabCPU.Controls.Add(Me.btnCP)
        Me.tabCPU.Controls.Add(Me.radCP4)
        Me.tabCPU.Controls.Add(Me.radCP3)
        Me.tabCPU.Controls.Add(Me.radCP2)
        Me.tabCPU.Controls.Add(Me.radCP1)
        Me.tabCPU.Controls.Add(Me.PictureBox9)
        Me.tabCPU.Controls.Add(Me.PictureBox10)
        Me.tabCPU.Controls.Add(Me.PictureBox11)
        Me.tabCPU.Controls.Add(Me.PictureBox12)
        Me.tabCPU.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabCPU.Location = New System.Drawing.Point(4, 36)
        Me.tabCPU.Name = "tabCPU"
        Me.tabCPU.Size = New System.Drawing.Size(887, 365)
        Me.tabCPU.TabIndex = 2
        Me.tabCPU.Text = "Processor"
        '
        'txtCP
        '
        Me.txtCP.Location = New System.Drawing.Point(569, 334)
        Me.txtCP.Name = "txtCP"
        Me.txtCP.Size = New System.Drawing.Size(100, 24)
        Me.txtCP.TabIndex = 39
        Me.txtCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(482, 337)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 19)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "Quantity(s)"
        '
        'btnCP
        '
        Me.btnCP.Location = New System.Drawing.Point(675, 330)
        Me.btnCP.Name = "btnCP"
        Me.btnCP.Size = New System.Drawing.Size(206, 32)
        Me.btnCP.TabIndex = 37
        Me.btnCP.Text = "Add To Cart"
        Me.btnCP.UseVisualStyleBackColor = True
        '
        'radCP4
        '
        Me.radCP4.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radCP4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radCP4.Location = New System.Drawing.Point(675, 219)
        Me.radCP4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radCP4.Name = "radCP4"
        Me.radCP4.Size = New System.Drawing.Size(200, 65)
        Me.radCP4.TabIndex = 36
        Me.radCP4.TabStop = True
        Me.radCP4.Text = "AMD Ryzen ThreadRipper" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 2400.00"
        Me.radCP4.UseVisualStyleBackColor = True
        '
        'radCP3
        '
        Me.radCP3.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radCP3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radCP3.Location = New System.Drawing.Point(455, 215)
        Me.radCP3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radCP3.Name = "radCP3"
        Me.radCP3.Size = New System.Drawing.Size(163, 65)
        Me.radCP3.TabIndex = 35
        Me.radCP3.TabStop = True
        Me.radCP3.Text = "AMD Ryzen 9" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 1500.00" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.radCP3.UseVisualStyleBackColor = True
        '
        'radCP2
        '
        Me.radCP2.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radCP2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radCP2.Location = New System.Drawing.Point(235, 219)
        Me.radCP2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radCP2.Name = "radCP2"
        Me.radCP2.Size = New System.Drawing.Size(163, 56)
        Me.radCP2.TabIndex = 34
        Me.radCP2.TabStop = True
        Me.radCP2.Text = "AMD Ryzen 7" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 850.00" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.radCP2.UseVisualStyleBackColor = True
        '
        'radCP1
        '
        Me.radCP1.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radCP1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radCP1.Location = New System.Drawing.Point(15, 219)
        Me.radCP1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radCP1.Name = "radCP1"
        Me.radCP1.Size = New System.Drawing.Size(172, 56)
        Me.radCP1.TabIndex = 33
        Me.radCP1.TabStop = True
        Me.radCP1.Text = "AMD Ryzen 5" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 650.00" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.radCP1.UseVisualStyleBackColor = True
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.White
        Me.PictureBox9.BackgroundImage = Global.GroupProj.My.Resources.Resources.process4
        Me.PictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox9.Location = New System.Drawing.Point(675, 15)
        Me.PictureBox9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox9.TabIndex = 32
        Me.PictureBox9.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BackgroundImage = Global.GroupProj.My.Resources.Resources.process3
        Me.PictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox10.Location = New System.Drawing.Point(455, 15)
        Me.PictureBox10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox10.TabIndex = 31
        Me.PictureBox10.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.BackgroundImage = Global.GroupProj.My.Resources.Resources.process2
        Me.PictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox11.Location = New System.Drawing.Point(235, 15)
        Me.PictureBox11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox11.TabIndex = 30
        Me.PictureBox11.TabStop = False
        '
        'PictureBox12
        '
        Me.PictureBox12.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox12.BackgroundImage = Global.GroupProj.My.Resources.Resources.process1
        Me.PictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox12.Location = New System.Drawing.Point(15, 15)
        Me.PictureBox12.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox12.TabIndex = 29
        Me.PictureBox12.TabStop = False
        '
        'tabPSU
        '
        Me.tabPSU.BackColor = System.Drawing.Color.Black
        Me.tabPSU.Controls.Add(Me.txtPS)
        Me.tabPSU.Controls.Add(Me.Label4)
        Me.tabPSU.Controls.Add(Me.btnPS)
        Me.tabPSU.Controls.Add(Me.radPS4)
        Me.tabPSU.Controls.Add(Me.radPS3)
        Me.tabPSU.Controls.Add(Me.radPS2)
        Me.tabPSU.Controls.Add(Me.radPS1)
        Me.tabPSU.Controls.Add(Me.PictureBox21)
        Me.tabPSU.Controls.Add(Me.PictureBox22)
        Me.tabPSU.Controls.Add(Me.PictureBox23)
        Me.tabPSU.Controls.Add(Me.PictureBox24)
        Me.tabPSU.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabPSU.Location = New System.Drawing.Point(4, 36)
        Me.tabPSU.Name = "tabPSU"
        Me.tabPSU.Size = New System.Drawing.Size(887, 365)
        Me.tabPSU.TabIndex = 3
        Me.tabPSU.Text = "Power Supply"
        '
        'txtPS
        '
        Me.txtPS.Location = New System.Drawing.Point(569, 334)
        Me.txtPS.Name = "txtPS"
        Me.txtPS.Size = New System.Drawing.Size(100, 24)
        Me.txtPS.TabIndex = 31
        Me.txtPS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(482, 337)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 19)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Quantity(s)"
        '
        'btnPS
        '
        Me.btnPS.Location = New System.Drawing.Point(675, 330)
        Me.btnPS.Name = "btnPS"
        Me.btnPS.Size = New System.Drawing.Size(206, 32)
        Me.btnPS.TabIndex = 29
        Me.btnPS.Text = "Add To Cart"
        Me.btnPS.UseVisualStyleBackColor = True
        '
        'radPS4
        '
        Me.radPS4.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPS4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radPS4.Location = New System.Drawing.Point(675, 222)
        Me.radPS4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radPS4.Name = "radPS4"
        Me.radPS4.Size = New System.Drawing.Size(204, 65)
        Me.radPS4.TabIndex = 28
        Me.radPS4.TabStop = True
        Me.radPS4.Text = "Segotep RP650" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 450.00"
        Me.radPS4.UseVisualStyleBackColor = True
        '
        'radPS3
        '
        Me.radPS3.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPS3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radPS3.Location = New System.Drawing.Point(455, 222)
        Me.radPS3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radPS3.Name = "radPS3"
        Me.radPS3.Size = New System.Drawing.Size(200, 65)
        Me.radPS3.TabIndex = 27
        Me.radPS3.TabStop = True
        Me.radPS3.Text = "COOLER MASTER V SFX GOLD 550W" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 500.00"
        Me.radPS3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.radPS3.UseVisualStyleBackColor = True
        '
        'radPS2
        '
        Me.radPS2.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPS2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radPS2.Location = New System.Drawing.Point(235, 218)
        Me.radPS2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radPS2.Name = "radPS2"
        Me.radPS2.Size = New System.Drawing.Size(200, 69)
        Me.radPS2.TabIndex = 26
        Me.radPS2.TabStop = True
        Me.radPS2.Text = "GIGABYTE P850GM" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 700.00"
        Me.radPS2.UseVisualStyleBackColor = True
        '
        'radPS1
        '
        Me.radPS1.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPS1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radPS1.Location = New System.Drawing.Point(15, 218)
        Me.radPS1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radPS1.Name = "radPS1"
        Me.radPS1.Size = New System.Drawing.Size(200, 69)
        Me.radPS1.TabIndex = 25
        Me.radPS1.TabStop = True
        Me.radPS1.Text = "1st Player NGDP" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 800.00"
        Me.radPS1.UseVisualStyleBackColor = True
        '
        'PictureBox21
        '
        Me.PictureBox21.BackColor = System.Drawing.Color.White
        Me.PictureBox21.BackgroundImage = Global.GroupProj.My.Resources.Resources.ps4
        Me.PictureBox21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox21.Location = New System.Drawing.Point(675, 15)
        Me.PictureBox21.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox21.Name = "PictureBox21"
        Me.PictureBox21.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox21.TabIndex = 24
        Me.PictureBox21.TabStop = False
        '
        'PictureBox22
        '
        Me.PictureBox22.BackgroundImage = Global.GroupProj.My.Resources.Resources.ps3
        Me.PictureBox22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox22.Location = New System.Drawing.Point(455, 15)
        Me.PictureBox22.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox22.Name = "PictureBox22"
        Me.PictureBox22.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox22.TabIndex = 23
        Me.PictureBox22.TabStop = False
        '
        'PictureBox23
        '
        Me.PictureBox23.BackgroundImage = Global.GroupProj.My.Resources.Resources.ps2
        Me.PictureBox23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox23.Location = New System.Drawing.Point(235, 15)
        Me.PictureBox23.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox23.Name = "PictureBox23"
        Me.PictureBox23.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox23.TabIndex = 22
        Me.PictureBox23.TabStop = False
        '
        'PictureBox24
        '
        Me.PictureBox24.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox24.BackgroundImage = Global.GroupProj.My.Resources.Resources.ps1
        Me.PictureBox24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox24.Location = New System.Drawing.Point(15, 15)
        Me.PictureBox24.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox24.Name = "PictureBox24"
        Me.PictureBox24.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox24.TabIndex = 21
        Me.PictureBox24.TabStop = False
        '
        'tabGPU
        '
        Me.tabGPU.BackColor = System.Drawing.Color.Black
        Me.tabGPU.Controls.Add(Me.txtGP)
        Me.tabGPU.Controls.Add(Me.Label5)
        Me.tabGPU.Controls.Add(Me.btnGP)
        Me.tabGPU.Controls.Add(Me.radGP4)
        Me.tabGPU.Controls.Add(Me.radGP3)
        Me.tabGPU.Controls.Add(Me.radGP2)
        Me.tabGPU.Controls.Add(Me.radGP1)
        Me.tabGPU.Controls.Add(Me.PictureBox5)
        Me.tabGPU.Controls.Add(Me.PictureBox6)
        Me.tabGPU.Controls.Add(Me.PictureBox7)
        Me.tabGPU.Controls.Add(Me.PictureBox8)
        Me.tabGPU.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabGPU.Location = New System.Drawing.Point(4, 36)
        Me.tabGPU.Name = "tabGPU"
        Me.tabGPU.Size = New System.Drawing.Size(887, 365)
        Me.tabGPU.TabIndex = 4
        Me.tabGPU.Text = "Graphics"
        '
        'txtGP
        '
        Me.txtGP.Location = New System.Drawing.Point(572, 334)
        Me.txtGP.Name = "txtGP"
        Me.txtGP.Size = New System.Drawing.Size(100, 24)
        Me.txtGP.TabIndex = 39
        Me.txtGP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(485, 337)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 19)
        Me.Label5.TabIndex = 38
        Me.Label5.Text = "Quantity(s)"
        '
        'btnGP
        '
        Me.btnGP.Location = New System.Drawing.Point(678, 330)
        Me.btnGP.Name = "btnGP"
        Me.btnGP.Size = New System.Drawing.Size(206, 32)
        Me.btnGP.TabIndex = 37
        Me.btnGP.Text = "Add To Cart"
        Me.btnGP.UseVisualStyleBackColor = True
        '
        'radGP4
        '
        Me.radGP4.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radGP4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radGP4.Location = New System.Drawing.Point(675, 219)
        Me.radGP4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radGP4.Name = "radGP4"
        Me.radGP4.Size = New System.Drawing.Size(204, 57)
        Me.radGP4.TabIndex = 36
        Me.radGP4.TabStop = True
        Me.radGP4.Text = "MSi GTX 750 Ti" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 250.00"
        Me.radGP4.UseVisualStyleBackColor = True
        '
        'radGP3
        '
        Me.radGP3.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radGP3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radGP3.Location = New System.Drawing.Point(455, 219)
        Me.radGP3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radGP3.Name = "radGP3"
        Me.radGP3.Size = New System.Drawing.Size(180, 65)
        Me.radGP3.TabIndex = 35
        Me.radGP3.TabStop = True
        Me.radGP3.Text = "ZOTAC RTX 3060" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 1500.00"
        Me.radGP3.UseVisualStyleBackColor = True
        '
        'radGP2
        '
        Me.radGP2.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radGP2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radGP2.Location = New System.Drawing.Point(235, 219)
        Me.radGP2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radGP2.Name = "radGP2"
        Me.radGP2.Size = New System.Drawing.Size(200, 74)
        Me.radGP2.TabIndex = 34
        Me.radGP2.TabStop = True
        Me.radGP2.Text = "GIGABYTE GTX 1080 Ti" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 1300.00"
        Me.radGP2.UseVisualStyleBackColor = True
        '
        'radGP1
        '
        Me.radGP1.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radGP1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radGP1.Location = New System.Drawing.Point(15, 219)
        Me.radGP1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radGP1.Name = "radGP1"
        Me.radGP1.Size = New System.Drawing.Size(200, 74)
        Me.radGP1.TabIndex = 33
        Me.radGP1.TabStop = True
        Me.radGP1.Text = "ASROCK AMD Radeon 8000" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 800.00"
        Me.radGP1.UseVisualStyleBackColor = True
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.White
        Me.PictureBox5.BackgroundImage = Global.GroupProj.My.Resources.Resources.gc4
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.Location = New System.Drawing.Point(675, 15)
        Me.PictureBox5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox5.TabIndex = 32
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackgroundImage = Global.GroupProj.My.Resources.Resources.gc3
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox6.Location = New System.Drawing.Point(455, 15)
        Me.PictureBox6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox6.TabIndex = 31
        Me.PictureBox6.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackgroundImage = Global.GroupProj.My.Resources.Resources.gc1
        Me.PictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox7.Location = New System.Drawing.Point(235, 15)
        Me.PictureBox7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox7.TabIndex = 30
        Me.PictureBox7.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox8.BackgroundImage = Global.GroupProj.My.Resources.Resources.gc2
        Me.PictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox8.Location = New System.Drawing.Point(15, 15)
        Me.PictureBox8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox8.TabIndex = 29
        Me.PictureBox8.TabStop = False
        '
        'tabRAM
        '
        Me.tabRAM.BackColor = System.Drawing.Color.Black
        Me.tabRAM.Controls.Add(Me.txtR)
        Me.tabRAM.Controls.Add(Me.Label6)
        Me.tabRAM.Controls.Add(Me.btnR)
        Me.tabRAM.Controls.Add(Me.radR4)
        Me.tabRAM.Controls.Add(Me.radR3)
        Me.tabRAM.Controls.Add(Me.radR2)
        Me.tabRAM.Controls.Add(Me.radR1)
        Me.tabRAM.Controls.Add(Me.PictureBox17)
        Me.tabRAM.Controls.Add(Me.PictureBox18)
        Me.tabRAM.Controls.Add(Me.PictureBox19)
        Me.tabRAM.Controls.Add(Me.PictureBox20)
        Me.tabRAM.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabRAM.Location = New System.Drawing.Point(4, 36)
        Me.tabRAM.Name = "tabRAM"
        Me.tabRAM.Size = New System.Drawing.Size(887, 365)
        Me.tabRAM.TabIndex = 5
        Me.tabRAM.Text = "RAM"
        '
        'txtR
        '
        Me.txtR.Location = New System.Drawing.Point(572, 334)
        Me.txtR.Name = "txtR"
        Me.txtR.Size = New System.Drawing.Size(100, 24)
        Me.txtR.TabIndex = 31
        Me.txtR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(485, 337)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(81, 19)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Quantity(s)"
        '
        'btnR
        '
        Me.btnR.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnR.Location = New System.Drawing.Point(678, 330)
        Me.btnR.Name = "btnR"
        Me.btnR.Size = New System.Drawing.Size(206, 32)
        Me.btnR.TabIndex = 29
        Me.btnR.Text = "Add To Cart"
        Me.btnR.UseVisualStyleBackColor = True
        '
        'radR4
        '
        Me.radR4.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radR4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radR4.Location = New System.Drawing.Point(675, 217)
        Me.radR4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radR4.Name = "radR4"
        Me.radR4.Size = New System.Drawing.Size(204, 57)
        Me.radR4.TabIndex = 28
        Me.radR4.TabStop = True
        Me.radR4.Text = "PNY XLR8" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 550.00"
        Me.radR4.UseVisualStyleBackColor = True
        '
        'radR3
        '
        Me.radR3.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radR3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radR3.Location = New System.Drawing.Point(455, 217)
        Me.radR3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radR3.Name = "radR3"
        Me.radR3.Size = New System.Drawing.Size(200, 70)
        Me.radR3.TabIndex = 27
        Me.radR3.TabStop = True
        Me.radR3.Text = "CORSAIR VENGEANCE RGB" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 420.00"
        Me.radR3.UseVisualStyleBackColor = True
        '
        'radR2
        '
        Me.radR2.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radR2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radR2.Location = New System.Drawing.Point(235, 218)
        Me.radR2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radR2.Name = "radR2"
        Me.radR2.Size = New System.Drawing.Size(200, 72)
        Me.radR2.TabIndex = 26
        Me.radR2.TabStop = True
        Me.radR2.Text = "ADATA XPG Spectrix D50" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 380.00"
        Me.radR2.UseVisualStyleBackColor = True
        '
        'radR1
        '
        Me.radR1.Font = New System.Drawing.Font("Microsoft YaHei UI", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radR1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.radR1.Location = New System.Drawing.Point(15, 217)
        Me.radR1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radR1.Name = "radR1"
        Me.radR1.Size = New System.Drawing.Size(200, 72)
        Me.radR1.TabIndex = 25
        Me.radR1.TabStop = True
        Me.radR1.Text = "KINGSTON Fury Beast" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "RM 490.00"
        Me.radR1.UseVisualStyleBackColor = True
        '
        'PictureBox17
        '
        Me.PictureBox17.BackColor = System.Drawing.Color.White
        Me.PictureBox17.BackgroundImage = Global.GroupProj.My.Resources.Resources.ram4
        Me.PictureBox17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox17.Location = New System.Drawing.Point(675, 15)
        Me.PictureBox17.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox17.TabIndex = 24
        Me.PictureBox17.TabStop = False
        '
        'PictureBox18
        '
        Me.PictureBox18.BackgroundImage = Global.GroupProj.My.Resources.Resources.ram3
        Me.PictureBox18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox18.Location = New System.Drawing.Point(455, 15)
        Me.PictureBox18.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox18.TabIndex = 23
        Me.PictureBox18.TabStop = False
        '
        'PictureBox19
        '
        Me.PictureBox19.BackgroundImage = Global.GroupProj.My.Resources.Resources.ram2
        Me.PictureBox19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox19.Location = New System.Drawing.Point(235, 15)
        Me.PictureBox19.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox19.TabIndex = 22
        Me.PictureBox19.TabStop = False
        '
        'PictureBox20
        '
        Me.PictureBox20.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox20.BackgroundImage = Global.GroupProj.My.Resources.Resources.ram1
        Me.PictureBox20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox20.Location = New System.Drawing.Point(15, 15)
        Me.PictureBox20.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox20.Name = "PictureBox20"
        Me.PictureBox20.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox20.TabIndex = 21
        Me.PictureBox20.TabStop = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Black
        Me.MenuStrip1.Font = New System.Drawing.Font("Microsoft YaHei UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuToolStripMenuItem, Me.CartToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1262, 32)
        Me.MenuStrip1.TabIndex = 7
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuToolStripMenuItem
        '
        Me.MenuToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.MenuToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.MenuToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
        Me.MenuToolStripMenuItem.Size = New System.Drawing.Size(73, 28)
        Me.MenuToolStripMenuItem.Text = "Menu"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(224, 28)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'CartToolStripMenuItem
        '
        Me.CartToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.CartToolStripMenuItem.Name = "CartToolStripMenuItem"
        Me.CartToolStripMenuItem.Size = New System.Drawing.Size(59, 28)
        Me.CartToolStripMenuItem.Text = "Cart"
        '
        'imgCart
        '
        Me.imgCart.Image = CType(resources.GetObject("imgCart.Image"), System.Drawing.Image)
        Me.imgCart.Location = New System.Drawing.Point(1135, 561)
        Me.imgCart.Name = "imgCart"
        Me.imgCart.Size = New System.Drawing.Size(100, 100)
        Me.imgCart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgCart.TabIndex = 8
        Me.imgCart.TabStop = False
        '
        'lblCart
        '
        Me.lblCart.BackColor = System.Drawing.Color.White
        Me.lblCart.Font = New System.Drawing.Font("Microsoft YaHei UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCart.Location = New System.Drawing.Point(1208, 545)
        Me.lblCart.Name = "lblCart"
        Me.lblCart.Size = New System.Drawing.Size(42, 38)
        Me.lblCart.TabIndex = 9
        Me.lblCart.Text = "0"
        Me.lblCart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1262, 673)
        Me.Controls.Add(Me.lblCart)
        Me.Controls.Add(Me.imgCart)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.DoubleBuffered = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form4"
        Me.Text = "DecepTech Menu"
        Me.TabControl1.ResumeLayout(False)
        Me.tabCase.ResumeLayout(False)
        Me.tabCase.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabMB.ResumeLayout(False)
        Me.tabMB.PerformLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabCPU.ResumeLayout(False)
        Me.tabCPU.PerformLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabPSU.ResumeLayout(False)
        Me.tabPSU.PerformLayout()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabGPU.ResumeLayout(False)
        Me.tabGPU.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabRAM.ResumeLayout(False)
        Me.tabRAM.PerformLayout()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.imgCart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents tabCase As TabPage
    Friend WithEvents tabMB As TabPage
    Friend WithEvents tabCPU As TabPage
    Friend WithEvents tabPSU As TabPage
    Friend WithEvents tabGPU As TabPage
    Friend WithEvents tabRAM As TabPage
    Friend WithEvents radPC4 As RadioButton
    Friend WithEvents radPC2 As RadioButton
    Friend WithEvents radPC3 As RadioButton
    Friend WithEvents radPC1 As RadioButton
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents MenuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents radCP4 As RadioButton
    Friend WithEvents radCP3 As RadioButton
    Friend WithEvents radCP2 As RadioButton
    Friend WithEvents radCP1 As RadioButton
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents radMB4 As RadioButton
    Friend WithEvents radMB3 As RadioButton
    Friend WithEvents radMB2 As RadioButton
    Friend WithEvents radMB1 As RadioButton
    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox15 As PictureBox
    Friend WithEvents PictureBox16 As PictureBox
    Friend WithEvents radGP4 As RadioButton
    Friend WithEvents radGP3 As RadioButton
    Friend WithEvents radGP2 As RadioButton
    Friend WithEvents radGP1 As RadioButton
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents radR4 As RadioButton
    Friend WithEvents radR3 As RadioButton
    Friend WithEvents radR2 As RadioButton
    Friend WithEvents radR1 As RadioButton
    Friend WithEvents PictureBox17 As PictureBox
    Friend WithEvents PictureBox18 As PictureBox
    Friend WithEvents PictureBox19 As PictureBox
    Friend WithEvents PictureBox20 As PictureBox
    Friend WithEvents radPS4 As RadioButton
    Friend WithEvents radPS3 As RadioButton
    Friend WithEvents radPS2 As RadioButton
    Friend WithEvents radPS1 As RadioButton
    Friend WithEvents PictureBox21 As PictureBox
    Friend WithEvents PictureBox22 As PictureBox
    Friend WithEvents PictureBox23 As PictureBox
    Friend WithEvents PictureBox24 As PictureBox
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents imgCart As PictureBox
    Friend WithEvents btnPC As Button
    Friend WithEvents txtPC As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtMB As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnMB As Button
    Friend WithEvents txtCP As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btnCP As Button
    Friend WithEvents txtPS As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnPS As Button
    Friend WithEvents txtGP As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btnGP As Button
    Friend WithEvents txtR As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents btnR As Button
    Friend WithEvents lblCart As Label
    Friend WithEvents CartToolStripMenuItem As ToolStripMenuItem
End Class
